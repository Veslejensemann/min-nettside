library(readxl)
library(dplyr)
library(magrittr)
library(lubridate)
library(writexl)

# Functions to process data for a given the worksheets
process_portfolio <- function(sheet_name, monthly_returns) {
  portfolio <- read_excel("ESG Mid and Random ptfs.xlsx", sheet = sheet_name)
  
  big_stocks <- portfolio %>% filter(Size == "Mid") %>% pull(Stock)
  small_stocks <- portfolio %>% filter(Size == "Random") %>% pull(Stock)
  
  big_returns <- monthly_returns %>% select(Date, all_of(big_stocks))
  small_returns <- monthly_returns %>% select(Date, all_of(small_stocks))
  
  big_returns <- big_returns %>%
    rowwise() %>%
    mutate(average_return_big = mean(c_across(where(is.numeric)), na.rm = TRUE)) %>%
    select(Date, average_return_big)
  
  small_returns <- small_returns %>%
    rowwise() %>%
    mutate(average_return_small = mean(c_across(where(is.numeric)), na.rm = TRUE)) %>%
    select(Date, average_return_small)
  
  combined_returns <- big_returns %>%
    inner_join(small_returns, by = "Date") %>%
    mutate(Date = as.Date(Date))
  
  return(combined_returns)
}

# List of worksheets with portfolios
sheet_names <- c("2002","2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022") # Add all relevant worksheets from excel file

# Read monthly excess returns from excel
monthly_returns <- read_excel("ESG Mid and Random ptfs.xlsx", sheet = 2) # make sure you have the right sheet!!!

# Store results in individual dataframes
results_list <- list()
filtered_results_list <- list()

for (sheet in sheet_names) {
  combined_returns <- process_portfolio(sheet, monthly_returns)
  results_list[[sheet]] <- combined_returns
  
  # Filter data based on the sheet name
  year <- as.numeric(sheet)
  start_date <- as.Date(paste0(year, "-07-01"))
  end_date <- as.Date(paste0(year+1, "-06-30")) # Corrected the start and end date to cover the full fiscal year
  
  filtered_data <- combined_returns %>%
    filter(Date >= start_date & Date <= end_date)
  
  filtered_results_list[[sheet]] <- filtered_data
}

# Print filtered data
for (sheet in sheet_names) {
  print(paste("Filtered results for sheet:", sheet))
  print(filtered_results_list[[sheet]])
}

# Skriv DataFrame til en Excel-fil
write_xlsx(filtered_results_list, "output.xlsx")